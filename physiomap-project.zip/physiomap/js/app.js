/* ============================================================
   PhysioMap — app.js
   Main application controller
   ============================================================ */

'use strict';

/* ── State ─────────────────────────────────────────────────── */
const State = {
  gender: 'male',      // 'male' | 'female'
  view:   'front',     // 'front' | 'back'
  layers: {
    skin:    true,
    skeleton:true,
    muscles: false,
    arteries:false,
    veins:   false,
    nerves:  false,
    points:  true,
  },
  opacity: {
    skeleton: 0.85,
    muscles:  0.75,
    arteries: 0.90,
    veins:    0.90,
    nerves:   0.85,
  },
  scale:       1,
  selectedId:  null,
  notes:       {},     // { pointId: string }
};

/* ── DOM refs ──────────────────────────────────────────────── */
const $ = id => document.getElementById(id);
const svg = () => document.getElementById('bodySvg');

/* ── Init ──────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  renderBody();
  bindControls();
  applyLayers();
  updateZoomLabel();
});

/* ── Render body SVG ────────────────────────────────────────── */
function renderBody() {
  const el = $('bodySvg');
  if (!el) return;

  // Clear dynamic layers
  ['layer-points'].forEach(id => {
    const g = el.querySelector(`#${id}`);
    if (g) g.innerHTML = '';
  });

  renderPressurePoints();
  applyGenderVariant();
}

function applyGenderVariant() {
  const el = $('bodySvg');
  if (!el) return;
  // Toggle gender-specific shape adjustments
  el.querySelectorAll('[data-gender]').forEach(node => {
    const g = node.getAttribute('data-gender');
    node.style.display = (g === State.gender) ? '' : 'none';
  });
}

/* ── Pressure Points ────────────────────────────────────────── */
function renderPressurePoints() {
  const el = $('bodySvg');
  if (!el) return;
  const container = el.querySelector('#layer-points');
  if (!container) return;

  const viewKey = `${State.view}_${State.gender}`;

  PRESSURE_POINTS.forEach(pt => {
    const pos = pt.pos[viewKey];
    if (!pos) return; // not visible in this view/gender

    const isRight = pt.id.endsWith('_R');
    const mirrorX = isRight ? (200 - pos.x) : pos.x;

    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    g.setAttribute('class', 'pp-group');
    g.setAttribute('id', `pp-${pt.id}`);
    g.setAttribute('data-pt', pt.id);

    // Pulse ring
    const ring = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    ring.setAttribute('class', 'pp-ring');
    ring.setAttribute('cx', mirrorX);
    ring.setAttribute('cy', pos.y);
    ring.setAttribute('r', '8');
    ring.setAttribute('stroke', pt.color);
    ring.style.opacity = '0.5';

    // Main circle
    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('class', 'pp-circle');
    circle.setAttribute('cx', mirrorX);
    circle.setAttribute('cy', pos.y);
    circle.setAttribute('r', '7');
    circle.setAttribute('fill', hexToRgba(pt.color, 0.22));
    circle.setAttribute('stroke', pt.color);
    circle.setAttribute('stroke-width', '1.5');

    // Label
    const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    label.setAttribute('class', 'pp-label');
    label.setAttribute('x', mirrorX);
    label.setAttribute('y', pos.y + 3.5);
    label.setAttribute('text-anchor', 'middle');
    label.setAttribute('fill', pt.color);
    label.setAttribute('font-size', '4.2');
    label.textContent = pt.code;

    g.appendChild(ring);
    g.appendChild(circle);
    g.appendChild(label);

    g.addEventListener('click', () => selectPoint(pt.id));
    g.addEventListener('mouseenter', (e) => showTooltip(e, pt));
    g.addEventListener('mouseleave', hideTooltip);

    // Mirror point (symmetric)
    if (!isRight && pos.x !== 100) {
      const gR = g.cloneNode(true);
      gR.setAttribute('id', `pp-${pt.id}_R`);
      gR.setAttribute('data-pt', pt.id);
      const mirrorXR = 200 - mirrorX;
      gR.querySelectorAll('circle, text').forEach(n => n.setAttribute('cx', mirrorXR));
      gR.querySelectorAll('text').forEach(n => n.setAttribute('x', mirrorXR));
      gR.addEventListener('click', () => selectPoint(pt.id));
      gR.addEventListener('mouseenter', (e) => showTooltip(e, pt));
      gR.addEventListener('mouseleave', hideTooltip);
      container.appendChild(gR);
    }

    container.appendChild(g);
  });
}

/* ── Point selection ────────────────────────────────────────── */
function selectPoint(id) {
  // Deselect previous
  if (State.selectedId) {
    const prev = document.querySelector(`#pp-${State.selectedId}`);
    if (prev) prev.classList.remove('selected');
    const prevR = document.querySelector(`#pp-${State.selectedId}_R`);
    if (prevR) prevR.classList.remove('selected');
  }

  State.selectedId = id;

  const el = document.querySelector(`#pp-${id}`);
  if (el) el.classList.add('selected');
  const elR = document.querySelector(`#pp-${id}_R`);
  if (elR) elR.classList.add('selected');

  renderPointInfo(id);
}

function renderPointInfo(id) {
  const pt = PRESSURE_POINTS.find(p => p.id === id);
  if (!pt) return;

  const sys = SYSTEMS[pt.system] || {};
  const intDots = [1,2,3].map(i =>
    `<div class="int-dot${i <= pt.intensity ? ' filled' : ''}"></div>`
  ).join('');

  const tags = pt.tags.map(t => `<span class="tag t">${t}</span>`).join('');
  const warnings = pt.warnings.map(w => `<span class="tag w">⚠ ${w}</span>`).join('');

  $('point-info').innerHTML = `
    <div class="pt-name" style="color:${pt.color}">${pt.nameHe}</div>
    <div class="pt-code">${pt.code} · ${pt.nameEn}</div>

    <div class="info-block">
      <div class="info-lbl">מערכת</div>
      <div style="font-size:0.85rem; color:${pt.color}">${sys.label || pt.system}</div>
    </div>

    <div class="info-block">
      <div class="info-lbl">עוצמת לחץ מומלצת</div>
      <div class="intensity-row">${intDots}</div>
    </div>

    <div class="info-block">
      <div class="info-lbl">📍 מיקום אנטומי</div>
      <div class="info-val" style="border-color:${pt.color}">${pt.locationDesc}</div>
    </div>

    <div class="info-block">
      <div class="info-lbl">🩺 שימוש קליני</div>
      <div class="info-val" style="border-color:${pt.color}">${pt.usage}</div>
    </div>

    <div class="info-block">
      <div class="info-lbl">✋ טכניקה</div>
      <div class="info-val" style="border-color:${pt.color}">${pt.technique}</div>
    </div>

    <div class="info-block">
      <div class="info-lbl">תחומים</div>
      <div class="tag-row">${tags}</div>
    </div>

    ${pt.warnings.length ? `<div class="info-block">
      <div class="info-lbl">אזהרות</div>
      <div class="tag-row">${warnings}</div>
    </div>` : ''}
  `;

  $('notesText').value = State.notes[id] || '';
  const badge = $('rp-badge');
  if (badge) { badge.textContent = pt.code; badge.style.color = pt.color; badge.style.borderColor = pt.color; badge.style.background = hexToRgba(pt.color, 0.1); }
}

/* ── Layers ─────────────────────────────────────────────────── */
function applyLayers() {
  const el = $('bodySvg');
  if (!el) return;

  Object.entries(State.layers).forEach(([name, visible]) => {
    const layer = el.querySelector(`#layer-${name}`);
    if (!layer) return;
    const opacity = visible
      ? (name === 'skin' || name === 'points' ? 1 : (State.opacity[name] || 0.85))
      : 0;
    layer.style.opacity = opacity;
    layer.style.pointerEvents = visible ? '' : 'none';

    const btn = $(`btn-${name}`);
    if (btn) btn.classList.toggle('active', visible);
  });
}

function toggleLayer(name) {
  State.layers[name] = !State.layers[name];
  applyLayers();
}

/* ── Zoom ───────────────────────────────────────────────────── */
function zoom(factor) {
  State.scale = Math.min(Math.max(State.scale * factor, 0.4), 4);
  applyZoom();
}

function resetZoom() {
  State.scale = 1;
  applyZoom();
}

function applyZoom() {
  const wrapper = $('svg-wrapper');
  if (wrapper) wrapper.style.transform = `scale(${State.scale})`;
  updateZoomLabel();
}

function updateZoomLabel() {
  const el = $('zoom-level');
  if (el) el.textContent = Math.round(State.scale * 100) + '%';
}

/* ── Tooltip ────────────────────────────────────────────────── */
function showTooltip(e, pt) {
  const tip = $('tooltip');
  if (!tip) return;
  tip.textContent = `${pt.code} — ${pt.nameHe}`;
  const area = $('canvas-area');
  const rect = area.getBoundingClientRect();
  tip.style.left = (e.clientX - rect.left + 14) + 'px';
  tip.style.top  = (e.clientY - rect.top - 36) + 'px';
  tip.classList.add('show');
}

function hideTooltip() {
  const tip = $('tooltip');
  if (tip) tip.classList.remove('show');
}

/* ── Notes ──────────────────────────────────────────────────── */
function saveNote() {
  if (!State.selectedId) return;
  State.notes[State.selectedId] = $('notesText').value;
  const btn = document.querySelector('.save-btn');
  btn.textContent = '✅ נשמר';
  btn.classList.add('saved');
  setTimeout(() => {
    btn.textContent = '💾 שמור הערה';
    btn.classList.remove('saved');
  }, 1800);
}

/* ── Controls binding ───────────────────────────────────────── */
function bindControls() {
  // Gender
  $('g-male').addEventListener('click', () => {
    State.gender = 'male';
    $('g-male').classList.add('active');
    $('g-female').classList.remove('active');
    renderBody();
  });
  $('g-female').addEventListener('click', () => {
    State.gender = 'female';
    $('g-female').classList.add('active');
    $('g-male').classList.remove('active');
    renderBody();
  });

  // View
  $('v-front').addEventListener('click', () => {
    State.view = 'front';
    $('v-front').classList.add('active');
    $('v-back').classList.remove('active');
    renderBody();
  });
  $('v-back').addEventListener('click', () => {
    State.view = 'back';
    $('v-back').classList.add('active');
    $('v-front').classList.remove('active');
    renderBody();
  });

  // Zoom buttons
  $('btn-zoom-in').addEventListener('click', () => zoom(1.25));
  $('btn-zoom-out').addEventListener('click', () => zoom(0.8));
  $('btn-zoom-reset').addEventListener('click', resetZoom);

  // Mouse wheel zoom
  $('canvas-area').addEventListener('wheel', e => {
    e.preventDefault();
    zoom(e.deltaY < 0 ? 1.1 : 0.9);
  }, { passive: false });

  // Save note
  document.querySelector('.save-btn').addEventListener('click', saveNote);
}

/* ── Helpers ────────────────────────────────────────────────── */
function hexToRgba(hex, alpha) {
  const r = parseInt(hex.slice(1,3), 16);
  const g = parseInt(hex.slice(3,5), 16);
  const b = parseInt(hex.slice(5,7), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}
