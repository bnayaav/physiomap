// PhysioMap — Pressure Points Database
// Each point: id, code, nameHe, nameEn, system, location (x/y for front/back, male/female),
//             locationDesc, usage, technique, tags, warnings, color, intensity (1-3)

const PRESSURE_POINTS = [
  // ── HEAD & NECK ──────────────────────────────────────────────────────────────
  {
    id: "GB20", code: "GB20", nameHe: "פנג צ׳י", nameEn: "Feng Chi — Wind Pool",
    system: "gallbladder",
    pos: { front_male: {x:100,y:52}, back_male: {x:100,y:52},
           front_female: {x:100,y:50}, back_female: {x:100,y:50} },
    locationDesc: "בבסיס הגולגולת, בשקע בין שריר ה-SCM לטרפזיוס",
    usage: "כאבי ראש, מיגרנה, נוקשות צוואר, ורטיגו, כאבי עיניים, יתר לחץ דם",
    technique: "לחץ עמוק כלפי מעלה ופנימה. 30–60 שניות. אפשר לשלב עיסוי מעגלי.",
    tags: ["צוואר","מיגרנה","כאבי ראש","לחץ דם"],
    warnings: ["זהירות ביתר לחץ דם","לא ללחוץ בחוזקה יתרה בקשישים"],
    color: "#00d4ff", intensity: 2
  },
  {
    id: "GV20", code: "GV20", nameHe: "ביי הוי", nameEn: "Bai Hui — Hundred Convergences",
    system: "governing",
    pos: { front_male: {x:100,y:18}, back_male: {x:100,y:18},
           front_female: {x:100,y:18}, back_female: {x:100,y:18} },
    locationDesc: "בראש הגולגולת, בנקודת האמצע בין שתי האוזניים",
    usage: "כאבי ראש, ורטיגו, דיכאון, לחץ נפשי, ירידה קוגניטיבית",
    technique: "לחץ עדין עם קצה האצבע. 30 שניות. ניתן לעיסוי מעגלי קל.",
    tags: ["ראש","ורטיגו","נפשי"],
    warnings: [],
    color: "#cc88ff", intensity: 1
  },
  {
    id: "ST11", code: "ST11", nameHe: "צ׳י שה", nameEn: "Qi She",
    system: "stomach",
    pos: { front_male: {x:88,y:72}, back_male: null,
           front_female: {x:88,y:70}, back_female: null },
    locationDesc: "מעל עצם הבריח, בין שתי הראשים של שריר ה-SCM",
    usage: "כאבי גרון, נוקשות צוואר, קושי בבליעה, שיעול כרוני",
    technique: "לחץ עדין מאוד. 20 שניות. שמור על מגע קל בלבד.",
    tags: ["צוואר","גרון"],
    warnings: ["⚠ אזור קרוטיד — לחץ קל בלבד!","לא ללחוץ שני הצדדים בו-זמנית"],
    color: "#ffaa44", intensity: 1
  },

  // ── SHOULDER & UPPER BACK ────────────────────────────────────────────────────
  {
    id: "LI15", code: "LI15", nameHe: "ג׳יאן יו", nameEn: "Jian Yu — Shoulder Bone",
    system: "large_intestine",
    pos: { front_male: {x:57,y:88}, back_male: {x:57,y:88},
           front_female: {x:57,y:86}, back_female: {x:57,y:86} },
    locationDesc: "בקצה הקדמי של הכתף, בקו האמצעי של ראש הזרוע",
    usage: "כאבי כתף, הגבלת תנועה, דלקת גיד (טנדיניטיס), קרע בכף הכתף, פריקת כתף",
    technique: "לחץ עמוק עם אגודל. 45–60 שניות. שלב עם תנועות פסיביות של הכתף.",
    tags: ["כתף","תנועה","טנדיניטיס"],
    warnings: ["לא לאחר ניתוח כתף טרי (מתחת ל-3 חודשים)"],
    color: "#ffd700", intensity: 3
  },
  {
    id: "GB21", code: "GB21", nameHe: "ג׳יאן ג׳ינג", nameEn: "Jian Jing — Shoulder Well",
    system: "gallbladder",
    pos: { front_male: {x:80,y:82}, back_male: {x:80,y:82},
           front_female: {x:80,y:80}, back_female: {x:80,y:80} },
    locationDesc: "נקודת האמצע בין עמוד השדרה לקצה הכתף, על שריר הטרפזיוס",
    usage: "כאב ונוקשות כתפיים ועורף, כאבי ראש, מתח שרירי כרוני, כאב מופנה מצוואר",
    technique: "לחץ חזק למטה עם אגודל. 30–45 שניות. אחת הנקודות הנפוצות ביותר.",
    tags: ["טרפזיוס","כתף","עורף","כאב כרוני"],
    warnings: ["⚠ אסור בהריון — מגרה לידה","זהירות בלחץ דם גבוה"],
    color: "#ff6b6b", intensity: 3
  },
  {
    id: "SI11", code: "SI11", nameHe: "טיאן זונג", nameEn: "Tian Zong — Heavenly Gathering",
    system: "small_intestine",
    pos: { front_male: null, back_male: {x:142,y:108},
           front_female: null, back_female: {x:142,y:106} },
    locationDesc: "מרכז עצם השכמה (סקפולה), בשקע המרכזי",
    usage: "כאבי כתף אחורית, כאב בין השכמות, נוקשות גב עליון, כאב מופנה לזרוע",
    technique: "לחץ עמוק עם אגודל או מרפק. 30–60 שניות.",
    tags: ["שכמה","גב עליון","כתף"],
    warnings: [],
    color: "#ff9966", intensity: 2
  },
  {
    id: "BL13", code: "BL13", nameHe: "פיי שו", nameEn: "Fei Shu — Lung Transporting",
    system: "bladder",
    pos: { front_male: null, back_male: {x:107,y:105},
           front_female: null, back_female: {x:107,y:103} },
    locationDesc: "שתי אצבעות לצד עמוד השדרה, בגובה T3",
    usage: "בעיות נשימה, שיעול, אסתמה, כאבי גב עליון, חולשת גוף",
    technique: "לחץ בינוני עם שני האגודלות בו-זמנית. 30–45 שניות.",
    tags: ["נשימה","גב עליון","ריאות"],
    warnings: [],
    color: "#88ccff", intensity: 2
  },

  // ── ELBOW & ARM ──────────────────────────────────────────────────────────────
  {
    id: "LI11", code: "LI11", nameHe: "צ׳ו צ׳י", nameEn: "Qu Chi — Pool at the Bend",
    system: "large_intestine",
    pos: { front_male: {x:38,y:178}, back_male: {x:38,y:178},
           front_female: {x:38,y:176}, back_female: {x:38,y:176} },
    locationDesc: "בקצה החיצוני של קפל המרפק כאשר הזרוע כפופה 90 מעלות",
    usage: "טניס אלבו, כאבי מרפק, דלקות, כאבי יד/אמה, חיזוק חיסוני, כאב כרוני",
    technique: "לחץ אנכי חזק עם האגודל. 30–60 שניות. נקודה חזקה ויעילה.",
    tags: ["מרפק","יד","טניס אלבו","חיסון"],
    warnings: ["לא בהריון"],
    color: "#7cff6b", intensity: 3
  },
  {
    id: "HT7", code: "HT7", nameHe: "שן מן", nameEn: "Shen Men — Spirit Gate",
    system: "heart",
    pos: { front_male: {x:30,y:238}, back_male: null,
           front_female: {x:30,y:236}, back_female: null },
    locationDesc: "בפנים כף היד, בקצה המדיאלי של קפל כף היד",
    usage: "חרדה, נדודי שינה, דפיקות לב, עצבנות, מתח נפשי",
    technique: "לחץ עדין עם ציפורן האגודל. 30 שניות. מרגיע מאוד.",
    tags: ["שינה","חרדה","לב","נפשי"],
    warnings: [],
    color: "#ff88aa", intensity: 1
  },
  {
    id: "PC6", code: "PC6", nameHe: "נייגואן", nameEn: "Nei Guan — Inner Pass",
    system: "pericardium",
    pos: { front_male: {x:35,y:232}, back_male: null,
           front_female: {x:35,y:230}, back_female: null },
    locationDesc: "בפנים האמה, 3 אצבעות מעל קפל כף היד, בין שני הגידים",
    usage: "בחילות, הקאות, חרדה, הפרעות שינה, כאב חזה, דפיקות לב",
    technique: "לחץ עדין עם אגודל. 30 שניות. יעיל גם בצמיד לחץ.",
    tags: ["בחילה","חרדה","שינה"],
    warnings: [],
    color: "#00d4ff", intensity: 1
  },
  {
    id: "LI4", code: "LI4", nameHe: "הה גו", nameEn: "He Gu — Joining Valley",
    system: "large_intestine",
    pos: { front_male: {x:27,y:258}, back_male: null,
           front_female: {x:27,y:256}, back_female: null },
    locationDesc: "בגב כף היד, בשקע שבין בסיס האגודל והאצבע המורה",
    usage: "כאבי ראש, כאבי שיניים, כאב כללי, בחילה, כאבי מחזור, חיזוק חיסוני",
    technique: "לחץ חזק עם אגודל. 30–60 שניות. אחת הנקודות האוניברסליות.",
    tags: ["כאב","ראש","שיניים","מחזור","חיסון"],
    warnings: ["⚠ אסור בהריון — מגרה לידה"],
    color: "#ffd700", intensity: 3
  },

  // ── CHEST & ABDOMEN ───────────────────────────────────────────────────────────
  {
    id: "CV17", code: "CV17", nameHe: "שאן ג׳ונג", nameEn: "Shan Zhong — Chest Center",
    system: "conception",
    pos: { front_male: {x:100,y:118}, back_male: null,
           front_female: {x:100,y:115}, back_female: null },
    locationDesc: "מרכז עצם החזה (סטרנום), בגובה הצלע הרביעית",
    usage: "קשיי נשימה, חרדה, כאבי חזה, שיעול, אסתמה, כאב לב תפקודי",
    technique: "לחץ עדין עם ידיים חמות. 30–60 שניות. שלב עם נשימה עמוקה.",
    tags: ["חזה","נשימה","חרדה"],
    warnings: ["לא ללחוץ חזק","עדינות מיוחדת"],
    color: "#ff6b6b", intensity: 1
  },
  {
    id: "CV12", code: "CV12", nameHe: "ג׳ונג וואן", nameEn: "Zhong Wan — Middle Cavity",
    system: "conception",
    pos: { front_male: {x:100,y:148}, back_male: null,
           front_female: {x:100,y:145}, back_female: null },
    locationDesc: "בקו האמצע, מחצית הדרך בין הטבור לקצה עצם החזה",
    usage: "כאבי בטן, בעיות עיכול, בחילה, גאות, תיאבון לקוי",
    technique: "לחץ עדין-בינוני עם שלוש אצבעות. 30 שניות. לא אחרי ארוחה.",
    tags: ["עיכול","בטן","בחילה"],
    warnings: ["לא תוך שעה אחרי ארוחה","לא בהריון"],
    color: "#ffaa44", intensity: 1
  },
  {
    id: "ST36", code: "ST36", nameHe: "זו סאן ליי", nameEn: "Zu San Li — Leg Three Miles",
    system: "stomach",
    pos: { front_male: {x:70,y:385}, back_male: null,
           front_female: {x:70,y:382}, back_female: null },
    locationDesc: "4 אצבעות מתחת לברך, אצבע אחת לצד החיצוני של עצם השוק (טיביה)",
    usage: "חיזוק כללי, עייפות, כאבי ברך, בעיות עיכול, חיסון, כאבי רגל, קדחת",
    technique: "לחץ בינוני-חזק. 1–3 דקות. הנקודה החשובה ביותר לחיזוק.",
    tags: ["ברך","חיזוק","עייפות","עיכול","מפתח"],
    warnings: [],
    color: "#ffd700", intensity: 3
  },

  // ── LOWER BACK ────────────────────────────────────────────────────────────────
  {
    id: "BL23", code: "BL23", nameHe: "שן שו", nameEn: "Shen Shu — Kidney Transporting",
    system: "bladder",
    pos: { front_male: null, back_male: {x:100,y:178},
           front_female: null, back_female: {x:100,y:175} },
    locationDesc: "2 אצבעות לצדי עמוד השדרה, בגובה L2",
    usage: "כאבי גב תחתון כרוניים, בעיות כליות, עייפות כרונית, כאבי ירכיים, חולשת גפיים",
    technique: "לחץ עמוק עם שתי האגודלות. 60–90 שניות. יעיל בשילוב חום.",
    tags: ["גב תחתון","לומבר","כאב כרוני","כליות"],
    warnings: ["זהירות בדיסק בולט","לא בלחץ חד על עמוד שדרה"],
    color: "#ff6b6b", intensity: 3
  },
  {
    id: "BL40", code: "BL40", nameHe: "ווי ג׳ונג", nameEn: "Wei Zhong — Bend Middle",
    system: "bladder",
    pos: { front_male: null, back_male: {x:70,y:368},
           front_female: null, back_female: {x:70,y:365} },
    locationDesc: "מרכז קפל הברך (פוסה פופליטאלית)",
    usage: "כאבי גב תחתון, כאב סיאטי, ספאזם שרירי גב, כאבי ברך אחורית",
    technique: "לחץ בינוני עם אגודל. 30–45 שניות. המטופל שוכב על הבטן.",
    tags: ["גב תחתון","סיאטי","ברך"],
    warnings: ["לא ללחוץ חזק — אזור ורידי ועצבי רגיש"],
    color: "#88ccff", intensity: 2
  },
  {
    id: "GB30", code: "GB30", nameHe: "הואן טיאו", nameEn: "Huan Tiao — Jumping Circle",
    system: "gallbladder",
    pos: { front_male: {x:65,y:218}, back_male: {x:65,y:218},
           front_female: {x:65,y:215}, back_female: {x:65,y:215} },
    locationDesc: "בשליש החיצוני של הקו מהטרוקנטר לזנב הסוס",
    usage: "כאבי ירך, כאב סיאטי, כאבי גב תחתון מופנים לרגל, הגבלת תנועה בירך",
    technique: "לחץ עמוק עם מרפק. 45–60 שניות. מצריך לחץ חזק בשל עומק.",
    tags: ["ירך","סיאטי","גב"],
    warnings: ["לחץ עמוק בלבד"],
    color: "#7cff6b", intensity: 3
  },

  // ── KNEE & LEG ────────────────────────────────────────────────────────────────
  {
    id: "SP9", code: "SP9", nameHe: "יין לינג צ׳ואן", nameEn: "Yin Ling Quan — Yin Mound Spring",
    system: "spleen",
    pos: { front_male: {x:66,y:375}, back_male: null,
           front_female: {x:66,y:372}, back_female: null },
    locationDesc: "בצד המדיאלי של הרגל, מתחת לראש הטיביה",
    usage: "כאבי ברך, בצקת, בעיות עיכול, כאבי בטן, דלקת שלפוחית",
    technique: "לחץ אנכי עם אגודל. 30 שניות.",
    tags: ["ברך","בצקת","עיכול"],
    warnings: [],
    color: "#ffcc44", intensity: 2
  },

  // ── ANKLE & FOOT ──────────────────────────────────────────────────────────────
  {
    id: "KD3", code: "KD3", nameHe: "טאי שי", nameEn: "Tai Xi — Great Stream",
    system: "kidney",
    pos: { front_male: {x:58,y:463}, back_male: {x:58,y:463},
           front_female: {x:58,y:460}, back_female: {x:58,y:460} },
    locationDesc: "בין הקרסול המדיאלי לגיד האכילס, בנקודת האמצע",
    usage: "כאבי קרסול, חולשת גב תחתון, כאבי עקב, שמיעה ירודה, כאבי מחזור, חולשה כרונית",
    technique: "לחץ עדין-בינוני. 30–60 שניות. יעיל עם עיסוי קרסול.",
    tags: ["קרסול","עקב","גב תחתון","מחזור"],
    warnings: [],
    color: "#00d4ff", intensity: 2
  },
  {
    id: "SP6", code: "SP6", nameHe: "סאן יין ג׳יאו", nameEn: "San Yin Jiao — Three Yin Intersection",
    system: "spleen",
    pos: { front_male: {x:62,y:452}, back_male: null,
           front_female: {x:62,y:449}, back_female: null },
    locationDesc: "4 אצבעות מעל קרסול מדיאלי, מאחורי עצם השוק",
    usage: "כאבי מחזור, הפרעות הורמונליות, נדודי שינה, כאבי רגל, בעיות עיכול",
    technique: "לחץ בינוני-חזק. 30–60 שניות.",
    tags: ["מחזור","הורמונים","שינה","נשים"],
    warnings: ["⚠ אסור בהריון — מגרה לידה"],
    color: "#ff88cc", intensity: 2
  },
  {
    id: "LV3", code: "LV3", nameHe: "טאי צ׳ונג", nameEn: "Tai Chong — Great Surge",
    system: "liver",
    pos: { front_male: {x:67,y:480}, back_male: null,
           front_female: {x:67,y:477}, back_female: null },
    locationDesc: "בגב כף הרגל, בשקע שבין בסיס אצבע ראשונה ושנייה",
    usage: "כאבי ראש, כאבי עיניים, מתח, עצבנות, כאבי מחזור, כאבי רגל",
    technique: "לחץ חזק כלפי מעלה ופנימה. 30–45 שניות.",
    tags: ["ראש","מתח","מחזור","כבד"],
    warnings: ["לא בהריון"],
    color: "#88ff88", intensity: 2
  }
];

// Systems metadata
const SYSTEMS = {
  gallbladder:    { label: "כיס מרה",       color: "#00d4ff" },
  large_intestine:{ label: "מעי גס",         color: "#7cff6b" },
  small_intestine:{ label: "מעי דק",         color: "#ff9966" },
  stomach:        { label: "קיבה",            color: "#ffd700" },
  bladder:        { label: "שלפוחית",         color: "#88ccff" },
  kidney:         { label: "כליות",           color: "#00d4ff" },
  heart:          { label: "לב",              color: "#ff88aa" },
  pericardium:    { label: "פריקרד",          color: "#ff6699" },
  spleen:         { label: "טחול",            color: "#ffcc44" },
  liver:          { label: "כבד",             color: "#88ff88" },
  conception:     { label: "כלי ההיריון",     color: "#ffaa44" },
  governing:      { label: "כלי הממשל",       color: "#cc88ff" }
};

if (typeof module !== 'undefined') module.exports = { PRESSURE_POINTS, SYSTEMS };
